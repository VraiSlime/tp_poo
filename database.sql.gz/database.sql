-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: airbnb
-- ------------------------------------------------------
-- Server version	5.7.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES UTF8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `annonces`
--

DROP TABLE IF EXISTS `annonces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `annonces` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `titre` varchar(150) NOT NULL,
  `pays` varchar(150) NOT NULL,
  `ville` varchar(150) NOT NULL,
  `adresse` varchar(150) NOT NULL,
  `type_de_logement_id` int(10) NOT NULL,
  `taille` int(10) NOT NULL,
  `nbr_de_pieces` int(10) NOT NULL,
  `description` varchar(150) NOT NULL,
  `prix_par_nuit` int(10) NOT NULL,
  `nbr_de_couchages` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `type_de_logement_id` (`type_de_logement_id`),
  CONSTRAINT `annonces_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `annonces_ibfk_2` FOREIGN KEY (`type_de_logement_id`) REFERENCES `type_de_logement` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `annonces`
--

LOCK TABLES `annonces` WRITE;
/*!40000 ALTER TABLE `annonces` DISABLE KEYS */;
INSERT INTO `annonces` VALUES (35,3,'Villa ','France','Perpignan','11 rue gerard macabre',4,20,10,'ds',140,1),(39,3,'Villa ','France','Torreilles','11 rue gerard macabre',8,50,5,'ds',30,1),(41,4,'Mathias','France','Rio','11 rue gerard macabre',8,450,100,'maisno',20000,10),(42,3,'Appartement ','France','Paris ','11 rue emmanuel macaron',1,10,1,'Jolie appartement ',50,1),(43,3,'Cabane','France','Chessy','11 rue de disney ',10,50,5,'charmante cabane près de DisneyLand Paris',131,2);
/*!40000 ALTER TABLE `annonces` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `annonces_equipement`
--

DROP TABLE IF EXISTS `annonces_equipement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `annonces_equipement` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `equipement_id` int(10) NOT NULL,
  `annonces_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `equipement_id` (`equipement_id`),
  KEY `annonces_equipement_ibfk_2` (`annonces_id`),
  CONSTRAINT `annonces_equipement_ibfk_1` FOREIGN KEY (`equipement_id`) REFERENCES `equipement` (`id`),
  CONSTRAINT `annonces_equipement_ibfk_2` FOREIGN KEY (`annonces_id`) REFERENCES `annonces` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=138 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `annonces_equipement`
--

LOCK TABLES `annonces_equipement` WRITE;
/*!40000 ALTER TABLE `annonces_equipement` DISABLE KEYS */;
INSERT INTO `annonces_equipement` VALUES (110,1,35),(111,2,35),(118,1,39),(119,2,39),(120,3,39),(122,2,41),(123,3,41),(124,4,41),(125,1,42),(126,1,43),(127,2,43),(128,3,43),(129,4,43),(130,5,43),(131,6,43),(132,7,43),(133,8,43),(134,9,43),(135,10,43),(136,11,43),(137,19,43);
/*!40000 ALTER TABLE `annonces_equipement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipement`
--

DROP TABLE IF EXISTS `equipement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipement` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `label` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipement`
--

LOCK TABLES `equipement` WRITE;
/*!40000 ALTER TABLE `equipement` DISABLE KEYS */;
INSERT INTO `equipement` VALUES (1,'Wi-Fi'),(2,'Télévision'),(3,'Climatisation'),(4,'Chauffage'),(5,'Cuisine équipée'),(6,'Réfrigérateur'),(7,'Machine à café'),(8,'Micro-ondes'),(9,'Lave-vaisselle'),(10,'Lave-linge'),(11,'Sèche-linge'),(12,'Fer à repasser'),(13,'Sèche-cheveux'),(14,'Serviettes'),(15,'Draps'),(16,'Parking'),(17,'Piscine'),(18,'Balcon ou terrasse'),(19,'Jardin'),(20,'Barbecue'),(21,'Cheminée'),(22,'Bureau'),(23,'Gym'),(24,'Jacuzzi'),(25,'Sauna'),(26,'Ascenseur'),(27,'Détecteur de fumée'),(28,'Détecteur de monoxyde de carbone'),(29,'Kit de premiers secours'),(30,'Animaux autorisés'),(31,'Accès handicapé'),(32,'Lit bébé'),(33,'Chaise haute'),(34,'Jouets'),(35,'Console de jeux'),(36,'Lecteur DVD');
/*!40000 ALTER TABLE `equipement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `photos`
--

DROP TABLE IF EXISTS `photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `photos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `annonces_id` int(10) NOT NULL,
  `image_path` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `photos_ibfk_1` (`annonces_id`),
  CONSTRAINT `photos_ibfk_1` FOREIGN KEY (`annonces_id`) REFERENCES `annonces` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `photos`
--

LOCK TABLES `photos` WRITE;
/*!40000 ALTER TABLE `photos` DISABLE KEYS */;
INSERT INTO `photos` VALUES (35,35,'img/location.jpg'),(38,39,'img/un.jpg'),(40,41,'img/681e492b-a13d-49ee-a262-d05dea42b3fb.webp'),(41,42,'img/538ed313-a71f-4855-9548-ba879ff02d54.webp'),(42,43,'img/c4a54dfc-f5d6-41a7-bcb1-97bdfcedd94b.webp');
/*!40000 ALTER TABLE `photos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservations`
--

DROP TABLE IF EXISTS `reservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservations` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `annonces_id` int(10) NOT NULL,
  `date_debut` datetime DEFAULT NULL,
  `date_fin` datetime DEFAULT NULL,
  `nbr_de_personne` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `annonces_id` (`annonces_id`),
  CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `reservations_ibfk_2` FOREIGN KEY (`annonces_id`) REFERENCES `annonces` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservations`
--

LOCK TABLES `reservations` WRITE;
/*!40000 ALTER TABLE `reservations` DISABLE KEYS */;
INSERT INTO `reservations` VALUES (6,6,35,'2023-10-25 00:00:00','2023-10-30 00:00:00',5),(7,3,43,'2023-11-25 00:00:00','2023-11-30 00:00:00',3),(8,4,42,'2023-10-10 00:00:00','2023-10-13 00:00:00',1);
/*!40000 ALTER TABLE `reservations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `type_de_logement`
--

DROP TABLE IF EXISTS `type_de_logement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `type_de_logement` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `label` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `type_de_logement`
--

LOCK TABLES `type_de_logement` WRITE;
/*!40000 ALTER TABLE `type_de_logement` DISABLE KEYS */;
INSERT INTO `type_de_logement` VALUES (1,'Appartement'),(2,'Maison'),(3,'Studio'),(4,'Chambre '),(5,'Maison '),(6,'Riadh'),(7,'Camping'),(8,'Villa'),(9,'Cottage'),(10,'Cabane'),(11,'Bungalow'),(12,'Loft'),(13,'Péniche'),(14,'Chalet'),(15,'Manoir'),(16,'Château'),(17,'Ferme'),(18,'Igloo'),(19,'Dortoir');
/*!40000 ALTER TABLE `type_de_logement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `password` varchar(150) NOT NULL,
  `is_hote` tinyint(1) NOT NULL,
  `nom` varchar(150) NOT NULL,
  `prenom` varchar(150) NOT NULL,
  `date_inscription` datetime NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (3,'$2y$10$eFY76wXG8UhNms2KDmhUxuzG0ETsSD04clwr9eIxWHwc9vYMIoZ2O',0,'john','doe','2023-09-12 13:23:49','doe@doe.com'),(4,'$2y$10$qwjinGWDvws6p4xXCNjn..zV4H3NAirWwIX39/xbW38jLy4jAEr5m',0,'Bouabdallah','Mathias','2023-09-13 11:15:57','mathias.bouabdallah66@gmail.com'),(5,'$2y$10$mp8H0RQK6iHDXg43bs1I1eWSXUV9iogaSbFICefIPcWJYOhqW2UlW',0,'john','Mathias','2023-09-13 11:26:11','doe@dewey.com'),(6,'$2y$10$.7R/YRsu5oJV.vGc4GDjYeB/8mZpRg/Pim5shjp5uKye2CwKJRlQu',0,'Je','Suis','2023-09-13 11:37:30','Standard@stand');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-14 17:30:35
